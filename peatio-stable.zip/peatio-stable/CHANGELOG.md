* Add visible attribute to market and default visible is true
* I18n translations for Email template
* Put Our Mission and Features into README.md
* Add CHANGELOG.md
