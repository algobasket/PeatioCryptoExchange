class MemberTag < ActiveYamlBase
end
