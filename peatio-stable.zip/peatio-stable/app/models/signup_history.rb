class SignupHistory < ActiveRecord::Base

end
