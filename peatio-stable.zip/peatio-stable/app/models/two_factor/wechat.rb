class TwoFactor::Wechat < ::TwoFactor

end
